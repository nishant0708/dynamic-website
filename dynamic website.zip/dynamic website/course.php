<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,900&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <section class="subheader">
    <nav>
        <a href="index.html"><img src="eduford_img\logo.png"/></a>
        <div class="navlinks" id="navLinks">
            <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="course.php">COURSE</a></li>
                <li><a href="Blog.php">BLOG</a></li>
                <li><a href="Contact.php">CONTACT</a></li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav>
    <h1>Our Courses</h1>
  
    </section>
    <!---Course-->
    <section class="Course">
        <h1>Courses We Offer</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        <div class="row">
            <div class="courseCol">
                <h3>Intermediate</h3>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam veritatis in harum minus sunt iusto. Temporibus porro
                modi, saepe, incidunt alias velit vitae cumque, laboriosam adipisci possimus recusandae eaque ut.
            </div>
            <div class="courseCol">
                <h3>Degree</h3>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam veritatis in harum minus sunt iusto. Temporibus porro
                modi, saepe, incidunt alias velit vitae cumque, laboriosam adipisci possimus recusandae eaque ut.
            </div>
            <div class="courseCol">
                <h3>Post Graduation</h3>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam veritatis in harum minus sunt iusto. Temporibus porro
                modi, saepe, incidunt alias velit vitae cumque, laboriosam adipisci possimus recusandae eaque ut.
            </div>
        </div>
        </section>
        <!----Facilities-->
        <section class="facilities">
            <h1>Our Facilities</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
             <div class="row">
                <div class="facilitiesCol">
                    <img src="eduford_img\library.png"></img>
                    <h3>World Class Library</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sunt eos reiciendis ut quo dolorem modi esse ex officiis consequatur ab illo, vel cupiditate alias ipsum voluptatum rem sit nulla.</p>
                      
                </div>
                <div class="facilitiesCol">
                    <img src="eduford_img\basketball.png"></img>
                    <h3>Largest Play Ground</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sunt eos reiciendis ut quo dolorem modi esse ex officiis consequatur ab illo, vel cupiditate alias ipsum voluptatum rem sit nulla.</p>
                      
                </div>
                <div class="facilitiesCol">
                    <img src="eduford_img\cafeteria.png"></img>
                    <h3>Tasty and Healthy Food</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sunt eos reiciendis ut quo dolorem modi esse ex officiis consequatur ab illo, vel cupiditate alias ipsum voluptatum rem sit nulla.</p>
                      
                </div>
             </div>
     </section>
      

    <!---footer-->
    <section class="Footer">
        <h4>About Us</h4>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere rem neque fuga tempore deserunt quas totam pariatur debitis,<br/> nisi cupiditate ea, minus velit dolorem expedita explicabo culpa ad nemo necessitatibus!</p>
        
            <i class="fa fa-facebook" style=" color: #f44336; cursor: pointer;padding: 18px 0;"></i>
            <i class="fa fa-twitter" style=" color: #f44336; cursor: pointer;padding: 18px 0;"></i>
            <i class="fa fa-instagram" style=" color: #f44336; cursor: pointer;padding: 18px 0;"></i>
            <i class="fa fa-linkedin" style=" color: #f44336; cursor: pointer;padding: 18px 0;"></i>
      
    </section>














    <script src="script.js"></script>
</body>
</html>