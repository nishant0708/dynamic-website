<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,900&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <section class="subheader">
    <nav>
        <a href="index.html"><img src="eduford_img\logo.png"/></a>
        <div class="navlinks" id="navLinks">
            <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="course.php">COURSE</a></li>
                <li><a href="Blog.php">BLOG</a></li>
                <li><a href="Contact.php">CONTACT</a></li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav>
    <h1>Our Certificate & Online Pograms for 2023</h1>
  
    </section>
      <!---blog content-->
      <div class="blogContent">
        <div class="row">
            <div class="blogleft">
                <img src="eduford_img/certificate.jpg">
                <h2>Our Certificate & Online Pograms for 2023</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro voluptatum tempore blanditiis, voluptates sapiente unde. Porro, architecto maxime laborum consequuntur esse repellendus eos id voluptas cumque fuga! Porro, consequuntur doloribus.</p>
                <br/>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Blanditiis, debitis cum ipsum minima consequatur saepe possimus, vero corrupti, velit nisi dicta. Reprehenderit tenetur eaque dolorem eveniet est, in minima voluptas.</p>
                <br/>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, voluptas debitis rem tempore voluptatem culpa perferendis similique voluptatibus non magni odio deserunt, ad quis recusandae perspiciatis mollitia totam, beatae ratione?</p>
                <br/>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ratione, est esse, aliquid optio qui dolorum sunt nostrum cum, facilis iusto necessitatibus veritatis. Tempora optio corrupti magni sunt maiores? Enim?</p>
                <br/>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ratione, est esse, aliquid optio qui dolorum sunt nostrum cum, facilis iusto necessitatibus veritatis. Tempora optio corrupti magni sunt maiores? Enim?</p>
                 
                <div class="commentbox">
                    <h3>Leave a comment</h3>
                    <form class="commentform" action="comment-handler.php" method="post">
                        <input type="text" name="user" placeholder="Enter name">
                        <input type="email" name="email" placeholder="Enter Email">
                        <textarea row="5"  name="comment" placeholder="Your comment"></textarea>
                        <button type="submit" class="herobtn redbtn">POST COMMENT</button>

                    </form>

                </div>











            </div>
            <div class="blogright">
                <h3>Post Categories</h3>
                <div>
                    <span>Business Analytics</span>
                    <span>21</span>
                </div>
                <div>
                    <span>Data Science</span>
                    <span>23</span>
                </div>
                <div>
                    <span>Information Technology</span>
                    <span>27</span>
                </div>
                <div>
                    <span>Machine Learning</span>
                    <span>31</span>
                </div>
                <div>
                    <span>Developnment</span>
                    <span>51</span>
                    </div>
                    <div>
                        <span>Statistics</span>
                        <span>74</span>
                    </div>
                
            </div>
        </div>
      </div>
      

    <!---footer-->
    <section class="Footer">
        <h4>About Us</h4>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere rem neque fuga tempore deserunt quas totam pariatur debitis,<br/> nisi cupiditate ea, minus velit dolorem expedita explicabo culpa ad nemo necessitatibus!</p>
        
            <i class="fa fa-facebook" style=" color: #f44336; cursor: pointer;padding: 18px 0;"></i>
            <i class="fa fa-twitter" style=" color: #f44336; cursor: pointer;padding: 18px 0;"></i>
            <i class="fa fa-instagram" style=" color: #f44336; cursor: pointer;padding: 18px 0;"></i>
            <i class="fa fa-linkedin" style=" color: #f44336; cursor: pointer;padding: 18px 0;"></i>
      
    </section>














    <script src="script.js"></script>
</body>
</html>